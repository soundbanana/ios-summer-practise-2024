class Vehicle{
    var carBrand: String
    var carModel: String
    var productionYear: Int
    var power: Int
    var torque: Int
    
    init(carBrand:String, carModel:String, productionYear:Int, power:Int, torque:Int) {
        self.carBrand = carBrand
        self.carModel = carModel
        self.productionYear = productionYear
        self.power = power
        self.torque = torque
    }
    
    func displayInfo() {
            print("Car Brand: \(carBrand), model: \(carModel), producted in \(productionYear).")
    }
}

class Toyota: Vehicle{
    var amountOfOwners: Int
    
    override init(carBrand: String, carModel:String, productionYear:Int, power:Int, torque:Int) {
        self.amountOfOwners = 15
        super.init(carBrand: "Toyota", carModel: carModel, productionYear: productionYear, power: power, torque: torque)
    }
    
    override func displayInfo() {
            print("Car Brand: \(carBrand), model: \(carModel), producted in \(productionYear), with \(power) HP and \(torque) Nm of torque.")
    }
}

class VAZ: Vehicle{
    var stage: Int
    
    override init(carBrand: String, carModel:String, productionYear:Int, power:Int, torque:Int) {
        self.stage = 2
        super.init(carBrand: "VAZ", carModel: carModel, productionYear: productionYear, power:power, torque:torque)
    }
    
    override func displayInfo() {
            print("Car Brand: \(carBrand), model: \(carModel), producted in \(productionYear), with \(power) HP and \(torque) Nm of torque.")
    }
}

class LandRover: Vehicle{
    override init(carBrand: String, carModel:String, productionYear:Int, power:Int, torque:Int) {
        super.init(carBrand: "Land Rover", carModel: carModel, productionYear: productionYear, power:power, torque:torque)
    }
    
    override func displayInfo() {
            print("Car Brand: \(carBrand), model: \(carModel), producted in \(productionYear), with \(power) HP and \(torque) Nm of torque.")
    }
}


class Volkswagen: Vehicle{
    override init(carBrand: String, carModel:String, productionYear:Int, power:Int, torque:Int) {

        super.init(carBrand: "Volkswagen", carModel: carModel, productionYear: productionYear, power:power, torque:torque)
    }
    
    override func displayInfo() {
            print("Car Brand: \(carBrand), model: \(carModel), producted in \(productionYear), with \(power) HP and \(torque) Nm of torque.")
    }
}

//не совсем понимаю зачем в задаче третий пункт, если есть конструкторы
extension Vehicle {
    static func createCar(carBrand: String, carModel: String, productionYear: Int, power: Int, torque: Int) -> Vehicle{
        switch carBrand{
        case "Toyota": return Toyota(carBrand: carBrand, carModel: carModel,productionYear: productionYear,power: power, torque: torque)
        case "VAZ": return VAZ(carBrand: carBrand, carModel: carModel,productionYear: productionYear,power: power, torque: torque)
        case "Land Rover": return LandRover(carBrand: carBrand, carModel: carModel,productionYear: productionYear,power: power, torque: torque)
        case "Volkswagen": return Volkswagen(carBrand: carBrand, carModel: carModel,productionYear: productionYear,power: power, torque: torque)
        default: return Vehicle(carBrand: carBrand, carModel: carModel,productionYear: productionYear, power:power, torque:torque)
        }
    }
}


func race(car1: Vehicle, car2: Vehicle) -> Vehicle{
    let carOneRating = car1.productionYear + car1.power + car1.torque
    let carTwoRating = car2.productionYear + car2.power + car2.torque
    if carOneRating == carTwoRating{
        let randonNum = Int.random(in: 0...1)
        if randonNum == 1 {
            return car1
        }else{
            return car2
        }
    }else if carOneRating>carTwoRating{
        return car1
    }else{
        return car2
    }
}

func totalRace(cars: [Vehicle]) {
    var temporary = cars
    if cars.count % 2 == 0 {
        while temporary.count != 1 {
            var index1 = Int.random(in: 0..<temporary.count)
            var index2 = Int.random(in: 0..<temporary.count)
            
            while index1 == index2 {
                index2 = Int.random(in: 0..<temporary.count)
            }
            
            let car1 = temporary[index1]
            let car2 = temporary[index2]
            
            if index1 > index2 {
                temporary.remove(at: index1)
                temporary.remove(at: index2)
            } else {
                temporary.remove(at: index2)
                temporary.remove(at: index1)
            }
            
            let winner = race(car1: car1, car2: car2)
            print("\(winner.carBrand) won the race between \(car1.carBrand), \(car2.carBrand)")
            
            temporary.append(winner)
        }
        print("The winner of the race is \(temporary[0].carBrand)")
    }
}



let carOne = Vehicle(carBrand:"Toyota", carModel: "Celica",productionYear: 2010,power: 180,torque: 200)
let carTwo = Vehicle(carBrand:"VAZ", carModel: "2107",productionYear: 2013,power: 80,torque: 90)
let carThree = Vehicle(carBrand:"Land Rover", carModel: "Range Rover",productionYear: 2022,power: 340,torque: 400)
let carFour = Vehicle(carBrand:"Volkswagen", carModel: "Golf IV",productionYear: 2007,power: 100,torque: 120)

var cars = [carOne,carTwo,carThree,carFour]
totalRace(cars:cars)

